class Triangle(){
  constructor(strokeSize){

  }


}
